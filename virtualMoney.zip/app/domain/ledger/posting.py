"""Signed ledger posting value."""

from __future__ import annotations

from ..types import NonNilUUID, NonZeroMoneyMinor
from ..value_model import ValueModel


class Posting(ValueModel):
    """Signed change to one financial account in minimal units."""

    account_id: NonNilUUID
    amount_minor: NonZeroMoneyMinor
