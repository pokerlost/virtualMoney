"""Holds base router."""

from __future__ import annotations

from fastapi import APIRouter

from api.openapi import OpenAPITag

from . import capture, get, release, reserve

router = APIRouter(prefix="/holds", tags=[OpenAPITag.HOLDS])
router.include_router(reserve.router)
router.include_router(get.router)
router.include_router(release.router)
router.include_router(capture.router)
