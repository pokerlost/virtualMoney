"""Financial operations base router."""

from __future__ import annotations

from fastapi import APIRouter

from api.openapi import OpenAPITag

from . import get, refund

router = APIRouter(
    prefix="/financialOperations",
    tags=[OpenAPITag.FINANCIAL_OPERATIONS],
)
router.include_router(get.router)
router.include_router(refund.router)
