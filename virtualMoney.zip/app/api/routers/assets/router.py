"""Assets base router."""

from __future__ import annotations

from fastapi import APIRouter

from api.openapi import OpenAPITag

from . import get, get_by_code

router = APIRouter(prefix="/assets", tags=[OpenAPITag.ASSETS])
router.include_router(get.router)
router.include_router(get_by_code.router)
