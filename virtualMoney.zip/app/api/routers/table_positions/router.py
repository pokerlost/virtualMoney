"""Table positions base router."""

from __future__ import annotations

from fastapi import APIRouter

from api.openapi import OpenAPITag

from . import buy_in, cash_out, get, get_operations, re_buy

router = APIRouter(prefix="/tablePositions", tags=[OpenAPITag.TABLE_POSITIONS])
router.include_router(buy_in.router)
router.include_router(re_buy.router)
router.include_router(cash_out.router)
router.include_router(get.router)
router.include_router(get_operations.router)
