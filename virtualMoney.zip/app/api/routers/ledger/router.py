"""Ledger base router."""

from __future__ import annotations

from fastapi import APIRouter

from api.openapi import OpenAPITag

from . import get, post, reverse

router = APIRouter(prefix="/ledger", tags=[OpenAPITag.LEDGER])
router.include_router(post.router)
router.include_router(get.router)
router.include_router(reverse.router)
