"""Accounts base router."""

from __future__ import annotations

from fastapi import APIRouter

from api.openapi import OpenAPITag

from . import create, get, get_balance, get_financial_history

router = APIRouter(prefix="/accounts", tags=[OpenAPITag.ACCOUNTS])
router.include_router(create.router)
router.include_router(get.router)
router.include_router(get_balance.router)
router.include_router(get_financial_history.router)
