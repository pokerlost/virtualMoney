"""Accounts API area."""

from __future__ import annotations

from .router import router

__all__ = ("router",)
