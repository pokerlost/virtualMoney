"""Account creation use case."""

from __future__ import annotations

import logfire

from application.errors import (
    AccountBalanceMissing,
    AccountCreationConflict,
    AssetNotFound,
)
from persistence.database.models import AccountModel
from persistence.repositories import (
    SQLAlchemyAccountBalanceRepository,
    SQLAlchemyAccountRepository,
    SQLAlchemyAssetRepository,
)

from .command import CreateAccountCommand


def _account_matches_draft(account: AccountModel, draft: AccountModel) -> bool:
    return (
        account.id == draft.id
        and account.asset_id == draft.asset_id
        and account.account_type is draft.account_type
        and account.owner_type is draft.owner_type
        and account.owner_id == draft.owner_id
        and account.status is draft.status
    )


class CreateAccountHandler:
    """Create an account and its zero projection atomically."""

    def __init__(
        self,
        accounts: SQLAlchemyAccountRepository,
        assets: SQLAlchemyAssetRepository,
        balances: SQLAlchemyAccountBalanceRepository,
    ) -> None:
        """Store request-scoped collaborators."""
        self._accounts = accounts
        self._assets = assets
        self._balances = balances

    async def _resolve_replay(self, account: AccountModel, draft: AccountModel) -> AccountModel:
        if not _account_matches_draft(account, draft):
            raise AccountCreationConflict()
        if await self._balances.get_by_account_id(account.id) is None:
            raise AccountBalanceMissing()
        return account

    async def execute(self, command: CreateAccountCommand) -> AccountModel:
        """Create an account or return its exact stable-identity replay."""
        draft = AccountModel(
            id=command.account_id,
            asset_id=command.asset_id,
            account_type=command.account_type,
            owner_type=command.owner_type,
            owner_id=command.owner_id,
            status=command.status,
        )
        existing = await self._accounts.get_by_id(draft.id)
        if existing is not None:
            return await self._resolve_replay(existing, draft)

        if await self._assets.get_by_id_for_update(draft.asset_id) is None:
            raise AssetNotFound()
        inserted = await self._accounts.insert_if_absent(draft)
        if not inserted:
            concurrent = await self._accounts.get_by_id(draft.id)
            if concurrent is None:
                raise AccountCreationConflict()
            return await self._resolve_replay(concurrent, draft)

        await self._balances.add_zero(draft.id)
        account = await self._accounts.get_by_id(draft.id)
        if account is None:
            raise AccountCreationConflict()
        logfire.info(
            "AccountModel and zero balance projection created",
            account_id=str(account.id),
            asset_id=str(account.asset_id),
        )
        return account
