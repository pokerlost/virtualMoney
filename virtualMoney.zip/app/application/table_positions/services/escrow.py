"""Concurrency-safe TABLE_ESCROW account provisioning."""

from __future__ import annotations

from typing import Final
from uuid import UUID, uuid5

from application.errors import (
    AccountBalanceMissing,
    AssetNotFound,
    TableEscrowUnavailable,
)
from domain.enums import AccountStatus, AccountType, AssetStatus, OwnerType
from persistence.database.models import AccountModel
from persistence.repositories import (
    SQLAlchemyAccountBalanceRepository,
    SQLAlchemyAccountRepository,
    SQLAlchemyAssetRepository,
)

# Immutable compatibility namespace for deterministic IDs issued by earlier releases.
TABLE_ESCROW_NAMESPACE: Final[UUID] = UUID("37be1d03-85aa-5c65-b109-916a74e2fbdb")


def _table_escrow_account_id(table_id: UUID, asset_id: UUID) -> UUID:
    return uuid5(TABLE_ESCROW_NAMESPACE, f"{table_id}:{asset_id}")


class TableEscrowProvisioner:
    """Get or create one table-owned account with a zero projection."""

    def __init__(
        self,
        accounts: SQLAlchemyAccountRepository,
        assets: SQLAlchemyAssetRepository,
        balances: SQLAlchemyAccountBalanceRepository,
    ) -> None:
        """Store request-scoped collaborators."""
        self._accounts = accounts
        self._assets = assets
        self._balances = balances

    async def _validate_existing(self, account: AccountModel) -> AccountModel:
        if account.status is AccountStatus.CLOSED:
            raise TableEscrowUnavailable()
        if await self._balances.get_by_account_id(account.id) is None:
            raise AccountBalanceMissing()
        return account

    async def get_or_create(self, *, table_id: UUID, asset_id: UUID) -> AccountModel:
        """Resolve one logical table/asset escrow inside the request transaction."""
        existing = await self._accounts.get_table_escrow(table_id, asset_id)
        asset = await self._assets.get_by_id(asset_id)
        if asset is None:
            raise AssetNotFound()
        if asset.status is not AssetStatus.ACTIVE:
            raise TableEscrowUnavailable()
        if existing is not None:
            return await self._validate_existing(existing)

        draft = AccountModel(
            id=_table_escrow_account_id(table_id, asset_id),
            asset_id=asset_id,
            account_type=AccountType.TABLE_ESCROW,
            owner_type=OwnerType.TABLE,
            owner_id=table_id,
            status=AccountStatus.ACTIVE,
        )
        inserted = await self._accounts.insert_if_absent(draft)
        if not inserted:
            concurrent = await self._accounts.get_table_escrow(table_id, asset_id)
            if concurrent is None:
                raise TableEscrowUnavailable()
            return await self._validate_existing(concurrent)

        await self._balances.add_zero(draft.id)
        return draft
