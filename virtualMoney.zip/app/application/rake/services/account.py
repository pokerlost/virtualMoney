"""Concurrency-safe RAKE account provisioning."""

from __future__ import annotations

from typing import Final
from uuid import UUID, uuid5

from application.errors import (
    AccountBalanceMissing,
    AssetNotFound,
    RakeAccountUnavailable,
)
from domain.enums import AccountStatus, AccountType, AssetStatus, OwnerType
from persistence.database.models import AccountModel
from persistence.repositories import (
    SQLAlchemyAccountBalanceRepository,
    SQLAlchemyAccountRepository,
    SQLAlchemyAssetRepository,
)

# Immutable compatibility identifiers for accounts issued by earlier releases.
RAKE_NAMESPACE: Final[UUID] = UUID("b55a2728-10fd-5c89-a74f-81791329ef34")
RAKE_OWNER_ID: Final[UUID] = UUID("9c28c0be-e4b0-581f-bac8-0394d842cc30")


class RakeAccountProvisioner:
    """Get or create one system-owned RAKE account per asset."""

    def __init__(
        self,
        accounts: SQLAlchemyAccountRepository,
        assets: SQLAlchemyAssetRepository,
        balances: SQLAlchemyAccountBalanceRepository,
    ) -> None:
        """Store request-scoped collaborators."""
        self._accounts = accounts
        self._assets = assets
        self._balances = balances

    async def _validate_existing(self, account: AccountModel) -> AccountModel:
        if (
            account.account_type is not AccountType.RAKE
            or account.owner_type is not OwnerType.SYSTEM
            or account.status is not AccountStatus.ACTIVE
        ):
            raise RakeAccountUnavailable()
        if await self._balances.get_by_account_id(account.id) is None:
            raise AccountBalanceMissing()
        return account

    async def get_or_create(self, asset_id: UUID) -> AccountModel:
        """Resolve one logical rake account inside the request transaction."""
        asset = await self._assets.get_by_id(asset_id)
        if asset is None:
            raise AssetNotFound()
        if asset.status is not AssetStatus.ACTIVE:
            raise RakeAccountUnavailable()

        existing = await self._accounts.get_rake_account(asset_id)
        if existing is not None:
            return await self._validate_existing(existing)

        account = AccountModel(
            id=uuid5(RAKE_NAMESPACE, str(asset_id)),
            asset_id=asset_id,
            account_type=AccountType.RAKE,
            owner_type=OwnerType.SYSTEM,
            owner_id=RAKE_OWNER_ID,
            status=AccountStatus.ACTIVE,
        )
        inserted = await self._accounts.insert_if_absent(account)
        if not inserted:
            concurrent = await self._accounts.get_rake_account(asset_id)
            if concurrent is None:
                raise RakeAccountUnavailable()
            return await self._validate_existing(concurrent)

        await self._balances.add_zero(account.id)
        return account
