"""Create immutable double-entry ledger schema.

Revision ID: 20260816_0002
Revises: 20260816_0001
Create Date: 2026-08-16
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

__all__ = (
    "downgrade",
    "upgrade",
)

revision: str = "20260816_0002"
down_revision: str | None = "20260816_0001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Create immutable journal and signed posting rows without balance columns."""
    op.create_table(
        "ledger_transactions",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("operation_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("asset_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("payload_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("transaction_type", sa.String(length=32), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("reference_type", sa.String(length=64), nullable=True),
        sa.Column("reference_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("description", sa.String(length=500), nullable=True),
        sa.Column(
            "reversal_of_transaction_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "posted_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "transaction_type IN ('ADJUSTMENT', 'REVERSAL')",
            name="ck_ledger_transactions_transaction_type",
        ),
        sa.CheckConstraint(
            "status = 'POSTED'",
            name="ck_ledger_transactions_status",
        ),
        sa.CheckConstraint(
            "payload_fingerprint ~ '^[0-9a-f]{64}$'",
            name="ck_ledger_transactions_payload_fingerprint",
        ),
        sa.CheckConstraint(
            "operation_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_ledger_transactions_operation_id_not_nil",
        ),
        sa.CheckConstraint(
            "(reference_type IS NULL AND reference_id IS NULL) OR "
            "(reference_type IS NOT NULL AND reference_id IS NOT NULL)",
            name="ck_ledger_transactions_reference_pair",
        ),
        sa.CheckConstraint(
            "reference_type IS NULL OR reference_type ~ '^[A-Z][A-Z0-9_]{0,63}$'",
            name="ck_ledger_transactions_reference_type",
        ),
        sa.CheckConstraint(
            "reference_id IS NULL OR "
            "reference_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_ledger_transactions_reference_id_not_nil",
        ),
        sa.CheckConstraint(
            "description IS NULL OR char_length(btrim(description)) BETWEEN 1 AND 500",
            name="ck_ledger_transactions_description",
        ),
        sa.CheckConstraint(
            "(transaction_type = 'ADJUSTMENT' AND reversal_of_transaction_id IS NULL) OR "
            "(transaction_type = 'REVERSAL' AND reversal_of_transaction_id IS NOT NULL)",
            name="ck_ledger_transactions_reversal_type",
        ),
        sa.CheckConstraint(
            "reversal_of_transaction_id IS NULL OR reversal_of_transaction_id <> id",
            name="ck_ledger_transactions_not_self_reversal",
        ),
        sa.CheckConstraint(
            "reversal_of_transaction_id IS NULL OR "
            "reversal_of_transaction_id <> "
            "'00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_ledger_transactions_reversal_id_not_nil",
        ),
        sa.CheckConstraint(
            "posted_at >= created_at",
            name="ck_ledger_transactions_posted_at",
        ),
        sa.ForeignKeyConstraint(
            ["asset_id"],
            ["assets.id"],
            name="fk_ledger_transactions_asset_id_assets",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["reversal_of_transaction_id"],
            ["ledger_transactions.id"],
            name="fk_ledger_transactions_reversal_id_ledger_transactions",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_ledger_transactions"),
        sa.UniqueConstraint(
            "operation_id",
            name="uq_ledger_transactions_operation_id",
        ),
        sa.UniqueConstraint(
            "reversal_of_transaction_id",
            name="uq_ledger_transactions_reversal_of_transaction_id",
        ),
    )

    op.create_table(
        "ledger_entries",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column(
            "ledger_transaction_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("account_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("amount_minor", sa.BigInteger(), nullable=False),
        sa.Column("sequence", sa.Integer(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "amount_minor <> 0",
            name="ck_ledger_entries_amount_non_zero",
        ),
        sa.CheckConstraint(
            "amount_minor <> -9223372036854775808",
            name="ck_ledger_entries_amount_reversible",
        ),
        sa.CheckConstraint(
            "sequence >= 1",
            name="ck_ledger_entries_sequence",
        ),
        sa.ForeignKeyConstraint(
            ["ledger_transaction_id"],
            ["ledger_transactions.id"],
            name="fk_ledger_entries_ledger_transaction_id_ledger_transactions",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["account_id"],
            ["accounts.id"],
            name="fk_ledger_entries_account_id_accounts",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_ledger_entries"),
        sa.UniqueConstraint(
            "ledger_transaction_id",
            "sequence",
            name="uq_ledger_entries_transaction_sequence",
        ),
    )
    op.create_index(
        "ix_ledger_entries_account_created_at",
        "ledger_entries",
        ["account_id", "created_at"],
        unique=False,
    )

    op.execute(
        sa.text(
            """
            CREATE FUNCTION reject_immutable_ledger_mutation()
            RETURNS trigger
            LANGUAGE plpgsql
            AS $$
            BEGIN
                RAISE EXCEPTION 'posted ledger records are immutable'
                    USING ERRCODE = '55000';
                RETURN NULL;
            END;
            $$
            """,
        ),
    )
    op.execute(
        sa.text(
            """
            CREATE TRIGGER trg_ledger_transactions_immutable
            BEFORE UPDATE OR DELETE ON ledger_transactions
            FOR EACH ROW
            EXECUTE FUNCTION reject_immutable_ledger_mutation()
            """,
        ),
    )
    op.execute(
        sa.text(
            """
            CREATE TRIGGER trg_ledger_entries_immutable
            BEFORE UPDATE OR DELETE ON ledger_entries
            FOR EACH ROW
            EXECUTE FUNCTION reject_immutable_ledger_mutation()
            """,
        ),
    )


def downgrade() -> None:
    """Drop only ledger schema objects created by this revision."""
    op.execute(
        sa.text(
            """
            DROP TRIGGER IF EXISTS trg_ledger_entries_immutable ON ledger_entries
            """,
        ),
    )
    op.execute(
        sa.text(
            """
            DROP TRIGGER IF EXISTS trg_ledger_transactions_immutable
            ON ledger_transactions
            """,
        ),
    )
    op.execute(sa.text("DROP FUNCTION IF EXISTS reject_immutable_ledger_mutation()"))
    op.drop_index(
        "ix_ledger_entries_account_created_at",
        table_name="ledger_entries",
    )
    op.drop_table("ledger_entries")
    op.drop_table("ledger_transactions")
