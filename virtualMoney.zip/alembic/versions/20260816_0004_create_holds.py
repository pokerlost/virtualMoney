"""Add held balance projection, holds and immutable hold operations.

Revision ID: 20260816_0004
Revises: 20260816_0003
Create Date: 2026-08-16
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

__all__ = (
    "downgrade",
    "upgrade",
)

revision: str = "20260816_0004"
down_revision: str | None = "20260816_0003"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Add hold state without changing existing posted ledger history."""
    op.add_column(
        "account_balances",
        sa.Column("held_balance_minor", sa.BigInteger(), nullable=True),
    )
    op.execute(
        sa.text(
            """
            UPDATE account_balances
            SET held_balance_minor = 0
            WHERE held_balance_minor IS NULL
            """,
        ),
    )
    op.alter_column(
        "account_balances",
        "held_balance_minor",
        existing_type=sa.BigInteger(),
        nullable=False,
        server_default=sa.text("0"),
    )
    op.create_check_constraint(
        "ck_account_balances_held_non_negative",
        "account_balances",
        "held_balance_minor >= 0",
    )

    op.drop_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        type_="check",
    )
    op.drop_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        type_="check",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        "transaction_type IN ('ADJUSTMENT', 'HOLD_CAPTURE', 'REVERSAL')",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        "(transaction_type IN ('ADJUSTMENT', 'HOLD_CAPTURE') "
        "AND reversal_of_transaction_id IS NULL) OR "
        "(transaction_type = 'REVERSAL' AND reversal_of_transaction_id IS NOT NULL)",
    )

    op.create_table(
        "holds",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("account_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("amount_minor", sa.BigInteger(), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("reference_type", sa.String(length=64), nullable=True),
        sa.Column("reference_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column("released_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("captured_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column(
            "capture_ledger_transaction_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
        sa.CheckConstraint(
            "amount_minor > 0",
            name="ck_holds_amount_positive",
        ),
        sa.CheckConstraint(
            "status IN ('ACTIVE', 'RELEASED', 'CAPTURED')",
            name="ck_holds_status",
        ),
        sa.CheckConstraint(
            "(reference_type IS NULL AND reference_id IS NULL) OR "
            "(reference_type IS NOT NULL AND reference_id IS NOT NULL)",
            name="ck_holds_reference_pair",
        ),
        sa.CheckConstraint(
            "reference_type IS NULL OR reference_type ~ '^[A-Z][A-Z0-9_]{0,63}$'",
            name="ck_holds_reference_type",
        ),
        sa.CheckConstraint(
            "reference_id IS NULL OR "
            "reference_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_holds_reference_id_not_nil",
        ),
        sa.CheckConstraint(
            "(status = 'ACTIVE' AND released_at IS NULL AND captured_at IS NULL "
            "AND capture_ledger_transaction_id IS NULL) OR "
            "(status = 'RELEASED' AND released_at IS NOT NULL AND captured_at IS NULL "
            "AND capture_ledger_transaction_id IS NULL) OR "
            "(status = 'CAPTURED' AND released_at IS NULL AND captured_at IS NOT NULL "
            "AND capture_ledger_transaction_id IS NOT NULL)",
            name="ck_holds_status_metadata",
        ),
        sa.CheckConstraint(
            "updated_at >= created_at",
            name="ck_holds_updated_at",
        ),
        sa.CheckConstraint(
            "released_at IS NULL OR "
            "(released_at >= created_at AND released_at <= updated_at)",
            name="ck_holds_released_at",
        ),
        sa.CheckConstraint(
            "captured_at IS NULL OR "
            "(captured_at >= created_at AND captured_at <= updated_at)",
            name="ck_holds_captured_at",
        ),
        sa.ForeignKeyConstraint(
            ["account_id"],
            ["accounts.id"],
            name="fk_holds_account_id_accounts",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["capture_ledger_transaction_id"],
            ["ledger_transactions.id"],
            name="fk_holds_capture_ledger_transaction_id_ledger_transactions",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_holds"),
        sa.UniqueConstraint(
            "capture_ledger_transaction_id",
            name="uq_holds_capture_ledger_transaction_id",
        ),
    )
    op.create_index(
        "ix_holds_account_status",
        "holds",
        ["account_id", "status"],
        unique=False,
    )

    op.create_table(
        "hold_operations",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("operation_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("hold_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("operation_type", sa.String(length=16), nullable=False),
        sa.Column("payload_fingerprint", sa.String(length=64), nullable=False),
        sa.Column(
            "ledger_transaction_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "operation_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_hold_operations_operation_id_not_nil",
        ),
        sa.CheckConstraint(
            "operation_type IN ('RESERVE', 'RELEASE', 'CAPTURE')",
            name="ck_hold_operations_operation_type",
        ),
        sa.CheckConstraint(
            "payload_fingerprint ~ '^[0-9a-f]{64}$'",
            name="ck_hold_operations_payload_fingerprint",
        ),
        sa.CheckConstraint(
            "(operation_type IN ('RESERVE', 'RELEASE') "
            "AND ledger_transaction_id IS NULL) OR "
            "(operation_type = 'CAPTURE' AND ledger_transaction_id IS NOT NULL)",
            name="ck_hold_operations_ledger_link",
        ),
        sa.ForeignKeyConstraint(
            ["hold_id"],
            ["holds.id"],
            name="fk_hold_operations_hold_id_holds",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["ledger_transaction_id"],
            ["ledger_transactions.id"],
            name="fk_hold_operations_ledger_transaction_id_ledger_transactions",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_hold_operations"),
        sa.UniqueConstraint(
            "operation_id",
            name="uq_hold_operations_operation_id",
        ),
        sa.UniqueConstraint(
            "ledger_transaction_id",
            name="uq_hold_operations_ledger_transaction_id",
        ),
    )
    op.create_index(
        "ix_hold_operations_hold_id",
        "hold_operations",
        ["hold_id"],
        unique=False,
    )

    op.execute(
        sa.text(
            """
            CREATE FUNCTION reject_hold_operation_mutation()
            RETURNS trigger
            LANGUAGE plpgsql
            AS $$
            BEGIN
                RAISE EXCEPTION 'hold operation records are immutable'
                    USING ERRCODE = '55000';
                RETURN NULL;
            END;
            $$
            """,
        ),
    )
    op.execute(
        sa.text(
            """
            CREATE TRIGGER trg_hold_operations_immutable
            BEFORE UPDATE OR DELETE ON hold_operations
            FOR EACH ROW
            EXECUTE FUNCTION reject_hold_operation_mutation()
            """,
        ),
    )


def downgrade() -> None:
    """Drop hold projection objects without deleting ledger history."""
    op.execute(
        sa.text(
            """
            DO $$
            BEGIN
                IF EXISTS (
                    SELECT 1
                    FROM ledger_transactions
                    WHERE transaction_type = 'HOLD_CAPTURE'
                ) THEN
                    RAISE EXCEPTION
                        'cannot downgrade while HOLD_CAPTURE ledger transactions exist'
                        USING ERRCODE = '55000';
                END IF;
            END;
            $$
            """,
        ),
    )
    op.execute(
        sa.text(
            """
            DROP TRIGGER IF EXISTS trg_hold_operations_immutable ON hold_operations
            """,
        ),
    )
    op.execute(sa.text("DROP FUNCTION IF EXISTS reject_hold_operation_mutation()"))
    op.drop_index(
        "ix_hold_operations_hold_id",
        table_name="hold_operations",
    )
    op.drop_table("hold_operations")
    op.drop_index(
        "ix_holds_account_status",
        table_name="holds",
    )
    op.drop_table("holds")

    op.drop_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        type_="check",
    )
    op.drop_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        type_="check",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        "transaction_type IN ('ADJUSTMENT', 'REVERSAL')",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        "(transaction_type = 'ADJUSTMENT' AND reversal_of_transaction_id IS NULL) OR "
        "(transaction_type = 'REVERSAL' AND reversal_of_transaction_id IS NOT NULL)",
    )

    op.drop_constraint(
        "ck_account_balances_held_non_negative",
        "account_balances",
        type_="check",
    )
    op.drop_column("account_balances", "held_balance_minor")
