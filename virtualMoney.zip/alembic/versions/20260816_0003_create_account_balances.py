"""Create and backfill persisted account balance projections.

Revision ID: 20260816_0003
Revises: 20260816_0002
Create Date: 2026-08-16
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

__all__ = (
    "downgrade",
    "upgrade",
)

revision: str = "20260816_0003"
down_revision: str | None = "20260816_0002"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Create the projection and backfill posted balances from the immutable ledger."""
    op.execute(
        sa.text(
            "LOCK TABLE accounts, ledger_entries IN SHARE MODE",
        ),
    )
    op.create_table(
        "account_balances",
        sa.Column(
            "account_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("posted_balance_minor", sa.BigInteger(), nullable=False),
        sa.Column("version", sa.BigInteger(), nullable=False),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "version >= 0",
            name="ck_account_balances_version_non_negative",
        ),
        sa.ForeignKeyConstraint(
            ["account_id"],
            ["accounts.id"],
            name="fk_account_balances_account_id_accounts",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("account_id", name="pk_account_balances"),
    )
    op.execute(
        sa.text(
            """
            INSERT INTO account_balances (
                account_id,
                posted_balance_minor,
                version,
                updated_at
            )
            SELECT
                accounts.id,
                COALESCE(SUM(ledger_entries.amount_minor), 0)::bigint,
                0,
                transaction_timestamp()
            FROM accounts
            LEFT JOIN ledger_entries
                ON ledger_entries.account_id = accounts.id
            GROUP BY accounts.id
            """,
        ),
    )


def downgrade() -> None:
    """Drop only the rebuildable projection table without changing ledger data."""
    op.drop_table("account_balances")
