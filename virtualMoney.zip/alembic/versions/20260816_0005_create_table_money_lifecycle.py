"""Create table escrow lifecycle positions and high-level operation audit.

Revision ID: 20260816_0005
Revises: 20260816_0004
Create Date: 2026-08-16
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

__all__ = (
    "downgrade",
    "upgrade",
)

revision: str = "20260816_0005"
down_revision: str | None = "20260816_0004"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Add durable positions, high-level audit, and the CASH_OUT ledger type."""
    op.drop_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        type_="check",
    )
    op.drop_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        type_="check",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        "transaction_type IN ('ADJUSTMENT', 'CASH_OUT', 'HOLD_CAPTURE', 'REVERSAL')",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        "(transaction_type IN ('ADJUSTMENT', 'CASH_OUT', 'HOLD_CAPTURE') "
        "AND reversal_of_transaction_id IS NULL) OR "
        "(transaction_type = 'REVERSAL' AND reversal_of_transaction_id IS NOT NULL)",
    )

    op.create_table(
        "player_table_positions",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("table_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("asset_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("user_account_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column(
            "table_escrow_account_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column("total_buy_in_minor", sa.BigInteger(), nullable=False),
        sa.Column("total_cash_out_minor", sa.BigInteger(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column("closed_at", sa.DateTime(timezone=True), nullable=True),
        sa.CheckConstraint(
            "user_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_player_table_positions_user_id_not_nil",
        ),
        sa.CheckConstraint(
            "table_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_player_table_positions_table_id_not_nil",
        ),
        sa.CheckConstraint(
            "status IN ('OPEN', 'CLOSED')",
            name="ck_player_table_positions_status",
        ),
        sa.CheckConstraint(
            "total_buy_in_minor > 0",
            name="ck_player_table_positions_buy_in_positive",
        ),
        sa.CheckConstraint(
            "total_cash_out_minor >= 0",
            name="ck_player_table_positions_cash_out_non_negative",
        ),
        sa.CheckConstraint(
            "user_account_id <> table_escrow_account_id",
            name="ck_player_table_positions_accounts_different",
        ),
        sa.CheckConstraint(
            "(status = 'OPEN' AND total_cash_out_minor = 0 AND closed_at IS NULL) OR "
            "(status = 'CLOSED' AND closed_at IS NOT NULL)",
            name="ck_player_table_positions_status_metadata",
        ),
        sa.CheckConstraint(
            "updated_at >= created_at",
            name="ck_player_table_positions_updated_at",
        ),
        sa.CheckConstraint(
            "closed_at IS NULL OR (closed_at >= created_at AND closed_at <= updated_at)",
            name="ck_player_table_positions_closed_at",
        ),
        sa.ForeignKeyConstraint(
            ["asset_id"],
            ["assets.id"],
            name="fk_player_table_positions_asset_id_assets",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["user_account_id"],
            ["accounts.id"],
            name="fk_player_table_positions_user_account_id_accounts",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["table_escrow_account_id"],
            ["accounts.id"],
            name="fk_player_table_positions_table_escrow_account_id_accounts",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_player_table_positions"),
    )
    op.create_index(
        "ix_player_table_positions_user_id",
        "player_table_positions",
        ["user_id"],
        unique=False,
    )
    op.create_index(
        "ix_player_table_positions_table_id",
        "player_table_positions",
        ["table_id"],
        unique=False,
    )
    op.create_index(
        "uq_player_table_positions_open_user_table_asset",
        "player_table_positions",
        ["user_id", "table_id", "asset_id"],
        unique=True,
        postgresql_where=sa.text("status = 'OPEN'"),
    )

    op.create_table(
        "table_money_operations",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("operation_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("position_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("operation_type", sa.String(length=16), nullable=False),
        sa.Column("payload_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("hold_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column(
            "ledger_transaction_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
        sa.Column("amount_minor", sa.BigInteger(), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "operation_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_table_money_operations_operation_id_not_nil",
        ),
        sa.CheckConstraint(
            "operation_type IN ('BUY_IN', 'REBUY', 'CASH_OUT')",
            name="ck_table_money_operations_operation_type",
        ),
        sa.CheckConstraint(
            "payload_fingerprint ~ '^[0-9a-f]{64}$'",
            name="ck_table_money_operations_payload_fingerprint",
        ),
        sa.CheckConstraint(
            "amount_minor >= 0",
            name="ck_table_money_operations_amount_non_negative",
        ),
        sa.CheckConstraint(
            "(operation_type IN ('BUY_IN', 'REBUY') AND amount_minor > 0 "
            "AND hold_id IS NOT NULL AND ledger_transaction_id IS NOT NULL) OR "
            "(operation_type = 'CASH_OUT' AND hold_id IS NULL AND "
            "((amount_minor = 0 AND ledger_transaction_id IS NULL) OR "
            "(amount_minor > 0 AND ledger_transaction_id IS NOT NULL)))",
            name="ck_table_money_operations_financial_links",
        ),
        sa.ForeignKeyConstraint(
            ["position_id"],
            ["player_table_positions.id"],
            name="fk_table_money_operations_position_id_player_table_positions",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["hold_id"],
            ["holds.id"],
            name="fk_table_money_operations_hold_id_holds",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["ledger_transaction_id"],
            ["ledger_transactions.id"],
            name="fk_table_money_operations_ledger_transaction_id_ledger",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_table_money_operations"),
        sa.UniqueConstraint(
            "operation_id",
            name="uq_table_money_operations_operation_id",
        ),
        sa.UniqueConstraint(
            "hold_id",
            name="uq_table_money_operations_hold_id",
        ),
        sa.UniqueConstraint(
            "ledger_transaction_id",
            name="uq_table_money_operations_ledger_transaction_id",
        ),
    )
    op.create_index(
        "ix_table_money_operations_position_id",
        "table_money_operations",
        ["position_id"],
        unique=False,
    )

    op.execute(
        sa.text(
            """
            CREATE FUNCTION reject_table_money_operation_mutation()
            RETURNS trigger
            LANGUAGE plpgsql
            AS $$
            BEGIN
                RAISE EXCEPTION 'table money operation records are immutable'
                    USING ERRCODE = '55000';
                RETURN NULL;
            END;
            $$
            """,
        ),
    )
    op.execute(
        sa.text(
            """
            CREATE TRIGGER trg_table_money_operations_immutable
            BEFORE UPDATE OR DELETE ON table_money_operations
            FOR EACH ROW
            EXECUTE FUNCTION reject_table_money_operation_mutation()
            """,
        ),
    )


def downgrade() -> None:
    """Drop only an empty lifecycle schema and safely narrow the ledger type."""
    op.execute(
        sa.text(
            """
            DO $$
            BEGIN
                IF EXISTS (SELECT 1 FROM player_table_positions)
                    OR EXISTS (
                        SELECT 1
                        FROM ledger_transactions
                        WHERE transaction_type = 'CASH_OUT'
                    ) THEN
                    RAISE EXCEPTION
                        'cannot downgrade while table money financial records exist'
                        USING ERRCODE = '55000';
                END IF;
            END;
            $$
            """,
        ),
    )
    op.execute(
        sa.text(
            """
            DROP TRIGGER IF EXISTS trg_table_money_operations_immutable
            ON table_money_operations
            """,
        ),
    )
    op.execute(
        sa.text("DROP FUNCTION IF EXISTS reject_table_money_operation_mutation()"),
    )
    op.drop_index(
        "ix_table_money_operations_position_id",
        table_name="table_money_operations",
    )
    op.drop_table("table_money_operations")
    op.drop_index(
        "uq_player_table_positions_open_user_table_asset",
        table_name="player_table_positions",
    )
    op.drop_index(
        "ix_player_table_positions_table_id",
        table_name="player_table_positions",
    )
    op.drop_index(
        "ix_player_table_positions_user_id",
        table_name="player_table_positions",
    )
    op.drop_table("player_table_positions")

    op.drop_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        type_="check",
    )
    op.drop_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        type_="check",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        "transaction_type IN ('ADJUSTMENT', 'HOLD_CAPTURE', 'REVERSAL')",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        "(transaction_type IN ('ADJUSTMENT', 'HOLD_CAPTURE') "
        "AND reversal_of_transaction_id IS NULL) OR "
        "(transaction_type = 'REVERSAL' AND reversal_of_transaction_id IS NOT NULL)",
    )
