"""Create internal assets and financial accounts.

Revision ID: 20260816_0001
Revises:
Create Date: 2026-08-16
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "20260816_0001"
down_revision: str | None = None
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Create the Asset/Account schema without seed data or balance columns."""
    op.create_table(
        "assets",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("code", sa.String(length=16), nullable=False),
        sa.Column("name", sa.String(length=128), nullable=False),
        sa.Column("minor_unit_scale", sa.SmallInteger(), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "code ~ '^[A-Z][A-Z0-9_]{1,15}$'",
            name="ck_assets_code_format",
        ),
        sa.CheckConstraint(
            "char_length(btrim(name)) BETWEEN 1 AND 128",
            name="ck_assets_name_not_blank",
        ),
        sa.CheckConstraint(
            "minor_unit_scale BETWEEN 0 AND 8",
            name="ck_assets_minor_unit_scale",
        ),
        sa.CheckConstraint(
            "status IN ('ACTIVE', 'INACTIVE')",
            name="ck_assets_status",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_assets"),
        sa.UniqueConstraint("code", name="uq_assets_code"),
    )

    op.create_table(
        "accounts",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("asset_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("account_type", sa.String(length=32), nullable=False),
        sa.Column("owner_type", sa.String(length=16), nullable=False),
        sa.Column("owner_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("status", sa.String(length=16), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "account_type IN ('USER', 'TREASURY', 'RAKE', 'TABLE_ESCROW')",
            name="ck_accounts_account_type",
        ),
        sa.CheckConstraint(
            "owner_type IN ('USER', 'TABLE', 'SYSTEM')",
            name="ck_accounts_owner_type",
        ),
        sa.CheckConstraint(
            "owner_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_accounts_owner_id_not_nil",
        ),
        sa.CheckConstraint(
            "status IN ('ACTIVE', 'FROZEN', 'CLOSED')",
            name="ck_accounts_status",
        ),
        sa.CheckConstraint(
            "(account_type = 'USER' AND owner_type = 'USER') OR "
            "(account_type = 'TABLE_ESCROW' AND owner_type = 'TABLE') OR "
            "(account_type IN ('TREASURY', 'RAKE') AND owner_type = 'SYSTEM')",
            name="ck_accounts_owner_matches_type",
        ),
        sa.ForeignKeyConstraint(
            ["asset_id"],
            ["assets.id"],
            name="fk_accounts_asset_id_assets",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_accounts"),
        sa.UniqueConstraint(
            "owner_type",
            "owner_id",
            "asset_id",
            "account_type",
            name="uq_accounts_owner_asset_type",
        ),
    )
    op.create_index("ix_accounts_asset_id", "accounts", ["asset_id"], unique=False)


def downgrade() -> None:
    """Drop only schema objects created by this revision."""
    op.drop_index("ix_accounts_asset_id", table_name="accounts")
    op.drop_table("accounts")
    op.drop_table("assets")
