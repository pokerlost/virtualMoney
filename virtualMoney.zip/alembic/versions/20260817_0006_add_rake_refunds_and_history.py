"""Add rake, full-compensation audit, processing actor, and history indexes.

Revision ID: 20260817_0006
Revises: 20260816_0005
Create Date: 2026-08-17
"""

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

__all__ = (
    "downgrade",
    "upgrade",
)

revision: str = "20260817_0006"
down_revision: str | None = "20260816_0005"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _add_actor_columns() -> None:
    op.add_column(
        "ledger_transactions",
        sa.Column("actor_service", sa.String(length=128), nullable=True),
    )
    op.create_check_constraint(
        "ck_ledger_transactions_actor_service",
        "ledger_transactions",
        "actor_service IS NULL OR "
        "actor_service ~ '^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$'",
    )
    op.add_column(
        "hold_operations",
        sa.Column("actor_service", sa.String(length=128), nullable=True),
    )
    op.create_check_constraint(
        "ck_hold_operations_actor_service",
        "hold_operations",
        "actor_service IS NULL OR "
        "actor_service ~ '^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$'",
    )
    op.add_column(
        "table_money_operations",
        sa.Column("actor_service", sa.String(length=128), nullable=True),
    )
    op.create_check_constraint(
        "ck_table_money_operations_actor_service",
        "table_money_operations",
        "actor_service IS NULL OR "
        "actor_service ~ '^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$'",
    )


def _extend_ledger_transaction_types() -> None:
    op.drop_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        type_="check",
    )
    op.drop_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        type_="check",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        "transaction_type IN "
        "('ADJUSTMENT', 'CASH_OUT', 'HOLD_CAPTURE', 'RAKE', 'REVERSAL')",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        "(transaction_type IN ('ADJUSTMENT', 'CASH_OUT', 'HOLD_CAPTURE', 'RAKE') "
        "AND reversal_of_transaction_id IS NULL) OR "
        "(transaction_type = 'REVERSAL' AND reversal_of_transaction_id IS NOT NULL)",
    )


def _create_history_indexes() -> None:
    op.execute(
        sa.text(
            """
            DO $$
            BEGIN
                IF EXISTS (
                    SELECT asset_id
                    FROM accounts
                    WHERE account_type = 'RAKE'
                    GROUP BY asset_id
                    HAVING count(*) > 1
                ) THEN
                    RAISE EXCEPTION
                        'cannot enforce one RAKE account per asset while duplicates exist'
                        USING ERRCODE = '23505';
                END IF;
            END;
            $$
            """,
        ),
    )
    op.create_index(
        "uq_accounts_rake_asset",
        "accounts",
        ["asset_id"],
        unique=True,
        postgresql_where=sa.text("account_type = 'RAKE'"),
    )
    op.create_index(
        "ix_ledger_transactions_posted_at_id",
        "ledger_transactions",
        ["posted_at", "id"],
        unique=False,
    )
    op.create_index(
        "ix_ledger_entries_account_transaction",
        "ledger_entries",
        ["account_id", "ledger_transaction_id"],
        unique=False,
    )
    op.drop_index(
        "ix_table_money_operations_position_id",
        table_name="table_money_operations",
    )
    op.create_index(
        "ix_table_money_operations_position_created_id",
        "table_money_operations",
        ["position_id", "created_at", "operation_id"],
        unique=False,
    )


def _create_rake_operations() -> None:
    op.create_table(
        "rake_operations",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("operation_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("table_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("hand_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("asset_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column(
            "table_escrow_account_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("rake_account_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("amount_minor", sa.BigInteger(), nullable=False),
        sa.Column(
            "ledger_transaction_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("payload_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("actor_service", sa.String(length=128), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "operation_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_rake_operations_operation_id_not_nil",
        ),
        sa.CheckConstraint(
            "table_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_rake_operations_table_id_not_nil",
        ),
        sa.CheckConstraint(
            "hand_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_rake_operations_hand_id_not_nil",
        ),
        sa.CheckConstraint(
            "amount_minor > 0",
            name="ck_rake_operations_amount_positive",
        ),
        sa.CheckConstraint(
            "table_escrow_account_id <> rake_account_id",
            name="ck_rake_operations_accounts_different",
        ),
        sa.CheckConstraint(
            "payload_fingerprint ~ '^[0-9a-f]{64}$'",
            name="ck_rake_operations_payload_fingerprint",
        ),
        sa.CheckConstraint(
            "actor_service ~ '^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$'",
            name="ck_rake_operations_actor_service",
        ),
        sa.ForeignKeyConstraint(
            ["asset_id"],
            ["assets.id"],
            name="fk_rake_operations_asset_id_assets",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["table_escrow_account_id"],
            ["accounts.id"],
            name="fk_rake_operations_table_escrow_account_id_accounts",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["rake_account_id"],
            ["accounts.id"],
            name="fk_rake_operations_rake_account_id_accounts",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["ledger_transaction_id"],
            ["ledger_transactions.id"],
            name="fk_rake_operations_ledger_transaction_id_ledger_transactions",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_rake_operations"),
        sa.UniqueConstraint(
            "operation_id",
            name="uq_rake_operations_operation_id",
        ),
        sa.UniqueConstraint(
            "ledger_transaction_id",
            name="uq_rake_operations_ledger_transaction_id",
        ),
    )
    op.create_index(
        "ix_rake_operations_table_hand",
        "rake_operations",
        ["table_id", "hand_id"],
        unique=False,
    )


def _create_refund_operations() -> None:
    op.create_table(
        "refund_operations",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column("operation_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column(
            "target_operation_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "original_ledger_transaction_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column(
            "reversal_ledger_transaction_id",
            postgresql.UUID(as_uuid=True),
            nullable=False,
        ),
        sa.Column("reason", sa.String(length=500), nullable=False),
        sa.Column("payload_fingerprint", sa.String(length=64), nullable=False),
        sa.Column("actor_service", sa.String(length=128), nullable=False),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=False,
        ),
        sa.CheckConstraint(
            "operation_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_refund_operations_operation_id_not_nil",
        ),
        sa.CheckConstraint(
            "target_operation_id <> '00000000-0000-0000-0000-000000000000'::uuid",
            name="ck_refund_operations_target_operation_id_not_nil",
        ),
        sa.CheckConstraint(
            "original_ledger_transaction_id <> reversal_ledger_transaction_id",
            name="ck_refund_operations_transactions_different",
        ),
        sa.CheckConstraint(
            "char_length(btrim(reason)) BETWEEN 1 AND 500",
            name="ck_refund_operations_reason",
        ),
        sa.CheckConstraint(
            "payload_fingerprint ~ '^[0-9a-f]{64}$'",
            name="ck_refund_operations_payload_fingerprint",
        ),
        sa.CheckConstraint(
            "actor_service ~ '^[A-Za-z0-9][A-Za-z0-9_.:-]{0,127}$'",
            name="ck_refund_operations_actor_service",
        ),
        sa.ForeignKeyConstraint(
            ["original_ledger_transaction_id"],
            ["ledger_transactions.id"],
            name="fk_refund_operations_original_ledger_transaction_id_ledger",
            ondelete="RESTRICT",
        ),
        sa.ForeignKeyConstraint(
            ["reversal_ledger_transaction_id"],
            ["ledger_transactions.id"],
            name="fk_refund_operations_reversal_ledger_transaction_id_ledger",
            ondelete="RESTRICT",
        ),
        sa.PrimaryKeyConstraint("id", name="pk_refund_operations"),
        sa.UniqueConstraint(
            "operation_id",
            name="uq_refund_operations_operation_id",
        ),
        sa.UniqueConstraint(
            "target_operation_id",
            name="uq_refund_operations_target_operation_id",
        ),
        sa.UniqueConstraint(
            "original_ledger_transaction_id",
            name="uq_refund_operations_original_ledger_transaction_id",
        ),
        sa.UniqueConstraint(
            "reversal_ledger_transaction_id",
            name="uq_refund_operations_reversal_ledger_transaction_id",
        ),
    )


def _create_immutable_audit_triggers() -> None:
    op.execute(
        sa.text(
            """
            CREATE FUNCTION reject_vmoney07_audit_mutation()
            RETURNS trigger
            LANGUAGE plpgsql
            AS $$
            BEGIN
                RAISE EXCEPTION 'rake and refund audit records are immutable'
                    USING ERRCODE = '55000';
                RETURN NULL;
            END;
            $$
            """,
        ),
    )
    for table_name in ("rake_operations", "refund_operations"):
        op.execute(
            sa.text(
                f"""
                CREATE TRIGGER trg_{table_name}_immutable
                BEFORE UPDATE OR DELETE ON {table_name}
                FOR EACH ROW
                EXECUTE FUNCTION reject_vmoney07_audit_mutation()
                """,
            ),
        )


def upgrade() -> None:
    """Add RAKE, full-compensation audit, processing actor fields, and history indexes."""
    _add_actor_columns()
    _extend_ledger_transaction_types()
    _create_history_indexes()
    _create_rake_operations()
    _create_refund_operations()
    _create_immutable_audit_triggers()


def _assert_safe_downgrade() -> None:
    op.execute(
        sa.text(
            """
            DO $$
            BEGIN
                IF EXISTS (SELECT 1 FROM rake_operations)
                    OR EXISTS (SELECT 1 FROM refund_operations)
                    OR EXISTS (
                        SELECT 1 FROM ledger_transactions
                        WHERE transaction_type = 'RAKE' OR actor_service IS NOT NULL
                    )
                    OR EXISTS (
                        SELECT 1 FROM hold_operations
                        WHERE actor_service IS NOT NULL
                    )
                    OR EXISTS (
                        SELECT 1 FROM table_money_operations
                        WHERE actor_service IS NOT NULL
                    ) THEN
                    RAISE EXCEPTION
                        'cannot downgrade while VMONEY-07 financial/audit data exists'
                        USING ERRCODE = '55000';
                END IF;
            END;
            $$
            """,
        ),
    )


def downgrade() -> None:
    """Drop only empty VMONEY-07 objects; financial data loss is prohibited."""
    _assert_safe_downgrade()

    for table_name in ("refund_operations", "rake_operations"):
        op.execute(
            sa.text(
                f"DROP TRIGGER IF EXISTS trg_{table_name}_immutable ON {table_name}",
            ),
        )
    op.execute(sa.text("DROP FUNCTION IF EXISTS reject_vmoney07_audit_mutation()"))

    op.drop_table("refund_operations")
    op.drop_index("ix_rake_operations_table_hand", table_name="rake_operations")
    op.drop_table("rake_operations")

    op.drop_index(
        "ix_table_money_operations_position_created_id",
        table_name="table_money_operations",
    )
    op.create_index(
        "ix_table_money_operations_position_id",
        "table_money_operations",
        ["position_id"],
        unique=False,
    )
    op.drop_index(
        "ix_ledger_entries_account_transaction",
        table_name="ledger_entries",
    )
    op.drop_index(
        "ix_ledger_transactions_posted_at_id",
        table_name="ledger_transactions",
    )
    op.drop_index("uq_accounts_rake_asset", table_name="accounts")

    op.drop_constraint(
        "ck_table_money_operations_actor_service",
        "table_money_operations",
        type_="check",
    )
    op.drop_column("table_money_operations", "actor_service")
    op.drop_constraint(
        "ck_hold_operations_actor_service",
        "hold_operations",
        type_="check",
    )
    op.drop_column("hold_operations", "actor_service")
    op.drop_constraint(
        "ck_ledger_transactions_actor_service",
        "ledger_transactions",
        type_="check",
    )
    op.drop_column("ledger_transactions", "actor_service")

    op.drop_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        type_="check",
    )
    op.drop_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        type_="check",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_transaction_type",
        "ledger_transactions",
        "transaction_type IN ('ADJUSTMENT', 'CASH_OUT', 'HOLD_CAPTURE', 'REVERSAL')",
    )
    op.create_check_constraint(
        "ck_ledger_transactions_reversal_type",
        "ledger_transactions",
        "(transaction_type IN ('ADJUSTMENT', 'CASH_OUT', 'HOLD_CAPTURE') "
        "AND reversal_of_transaction_id IS NULL) OR "
        "(transaction_type = 'REVERSAL' AND reversal_of_transaction_id IS NOT NULL)",
    )
