"""Remove audit fields coupled to the deleted local authentication model.

Revision ID: 20260817_0007
Revises: 20260817_0006
Create Date: 2026-08-17

The downgrade is intentionally unavailable. Removed actor labels cannot be reconstructed
without inventing audit data, and rake/refund actor columns were previously non-nullable.
"""

from collections.abc import Sequence

from alembic import op

__all__ = ("downgrade", "upgrade")

revision: str = "20260817_0007"
down_revision: str | None = "20260817_0006"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Drop local-auth actor constraints and columns while preserving financial data."""
    actor_columns = (
        ("ledger_transactions", "ck_ledger_transactions_actor_service"),
        ("hold_operations", "ck_hold_operations_actor_service"),
        ("table_money_operations", "ck_table_money_operations_actor_service"),
        ("rake_operations", "ck_rake_operations_actor_service"),
        ("refund_operations", "ck_refund_operations_actor_service"),
    )
    for table_name, constraint_name in actor_columns:
        op.drop_constraint(constraint_name, table_name, type_="check")
        op.drop_column(table_name, "actor_service")


def downgrade() -> None:
    """Refuse to fabricate authentication audit metadata that no longer exists."""
    raise RuntimeError(
        "20260817_0007 is irreversible because removed actor_service values cannot be restored",
    )
